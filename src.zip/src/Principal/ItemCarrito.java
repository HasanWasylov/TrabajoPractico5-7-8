package Principal;

public class ItemCarrito {
	private int codigo;
	
	public ItemCarrito(int codigo) {
		this.codigo = codigo;
	}
	
	public ItemCarrito() {
		
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	
}

